import type { AnalysisResults } from '../types';

const DEMO_RESULTS: AnalysisResults = {
  job_id: 'demo',
  analysis_completed_at: new Date().toISOString(),
  equipment_results: [
    {
      equipment_id: 'eq-001',
      type: 'transformer',
      label: 'Main Power Transformer',
      current_state: {
        anomalies_detected: [
          {
            anomaly_type: 'oil_leak',
            severity: 'WARNING',
            confidence: 0.89,
            location_description: 'Base seal, southwest corner',
            bounding_box: { x: 180, y: 320, width: 45, height: 30 },
          },
        ],
        overall_health_score: 72,
      },
      predictions: [
        {
          horizon_days: 30,
          predicted_anomalies: [
            {
              anomaly_type: 'oil_leak',
              severity: 'WARNING',
              confidence: 0.85,
              location_description: 'Base seal area',
              progression_notes: 'Leak area expected to expand 15-20%',
            },
          ],
          predicted_health_score: 68,
        },
        {
          horizon_days: 60,
          predicted_anomalies: [
            {
              anomaly_type: 'oil_leak',
              severity: 'CRITICAL',
              confidence: 0.78,
              location_description: 'Base seal and ground pooling',
              progression_notes: 'Oil level may drop below safe threshold',
            },
          ],
          predicted_health_score: 51,
        },
        {
          horizon_days: 90,
          predicted_anomalies: [
            {
              anomaly_type: 'oil_leak',
              severity: 'CRITICAL',
              confidence: 0.72,
              location_description: 'Extensive base area',
              progression_notes: 'Risk of thermal runaway if unaddressed',
            },
            {
              anomaly_type: 'thermal_hotspot',
              severity: 'CRITICAL',
              confidence: 0.65,
              location_description: 'Upper body thermal signature',
              progression_notes: 'Secondary thermal anomaly likely due to oil loss',
            },
          ],
          predicted_health_score: 34,
        },
      ],
      time_to_failure_estimate: {
        days: 52,
        confidence_range: { low: 38, high: 71 },
        failure_mode: 'Transformer oil depletion leading to overheating',
      },
      recommended_action: 'Schedule maintenance within 30 days to reseal base gasket',
      reasoning_chain:
        'Observed oil residue pattern at base indicates slow seal degradation. ' +
        'Historical progression rates for similar failures suggest 45-60 day window ' +
        'before critical oil loss. Thermal modeling indicates secondary hotspot ' +
        'development likely after 40% oil reduction.',
    },
    {
      equipment_id: 'eq-002',
      type: 'bushing',
      label: 'High-Voltage Bushing (North)',
      current_state: {
        anomalies_detected: [],
        overall_health_score: 89,
      },
      predictions: [
        { horizon_days: 30, predicted_anomalies: [], predicted_health_score: 87 },
        { horizon_days: 60, predicted_anomalies: [], predicted_health_score: 85 },
        { horizon_days: 90, predicted_anomalies: [], predicted_health_score: 82 },
      ],
      time_to_failure_estimate: null,
      recommended_action: 'Continue routine monitoring',
      reasoning_chain:
        'Bushing surface shows no signs of contamination, tracking marks, or physical damage. ' +
        'Porcelain housing intact with no visible cracks. Expected gradual weathering consistent ' +
        'with normal aging. No intervention required at this time.',
    },
  ],
  summary: {
    total_equipment_analyzed: 2,
    critical_findings: 0,
    warning_findings: 1,
    watch_findings: 0,
    nearest_failure_days: 52,
    priority_action: 'Main Power Transformer requires maintenance within 30 days',
  },
};

export default DEMO_RESULTS;
