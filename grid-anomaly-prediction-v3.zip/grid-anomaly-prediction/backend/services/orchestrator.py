"""
Job Orchestrator — manages the async processing pipeline for each job.

Pipeline stages:
  1. QUEUED → DETECTING: Run Cosmos Reason for equipment detection
  2. DETECTING → AWAITING_CONFIRMATION: Wait for user to confirm equipment
  3. AWAITING_CONFIRMATION → ANALYZING: Run Cosmos Predict + Reason pipeline
  4. ANALYZING → COMPLETE: Render output video
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Optional

from backend.config import settings
from backend.models.job import Job, JobStatus
from backend.services.mock_inference import mock_detect_equipment, mock_analyze_equipment
from backend.store.memory_store import job_store

logger = logging.getLogger(__name__)


class JobOrchestrator:
    """Coordinates async processing of analysis jobs."""

    def __init__(self):
        self._active_tasks: dict[str, asyncio.Task] = {}

    async def start_detection(self, job_id: str) -> None:
        """Launch detection as a background task."""
        task = asyncio.create_task(self._run_detection(job_id))
        self._active_tasks[job_id] = task

    async def start_analysis(self, job_id: str) -> None:
        """Launch full analysis pipeline as a background task."""
        task = asyncio.create_task(self._run_analysis(job_id))
        self._active_tasks[job_id] = task

    async def cancel(self, job_id: str) -> None:
        """Cancel a running job."""
        task = self._active_tasks.pop(job_id, None)
        if task and not task.done():
            task.cancel()

    # -- Detection pipeline ------------------------------------------------

    async def _run_detection(self, job_id: str) -> None:
        job = job_store.get(job_id)
        if not job:
            return

        try:
            job.transition(JobStatus.DETECTING)
            job.update_progress("equipment_detection", 0, "Starting equipment detection")

            async def progress_cb(stage, pct, operation):
                job.update_progress(stage, pct, operation)

            if settings.MOCK_MODELS:
                equipment = await mock_detect_equipment(
                    job.video_path or "", progress_callback=progress_cb
                )
            else:
                # TODO: Phase 2 — real Cosmos Reason inference
                equipment = await mock_detect_equipment(
                    job.video_path or "", progress_callback=progress_cb
                )

            job.detected_equipment = equipment
            job.transition(JobStatus.AWAITING_CONFIRMATION)
            job.update_progress("equipment_detection", 100, "Equipment detection complete")
            logger.info(
                "Job %s: detected %d equipment items", job_id, len(equipment)
            )

        except Exception as e:
            logger.exception("Job %s: detection failed", job_id)
            job.fail(str(e))
        finally:
            self._active_tasks.pop(job_id, None)

    # -- Analysis pipeline -------------------------------------------------

    async def _run_analysis(self, job_id: str) -> None:
        job = job_store.get(job_id)
        if not job:
            return

        try:
            job.update_progress("prediction_generation", 0, "Starting analysis pipeline")

            async def progress_cb(stage, pct, operation):
                job.update_progress(stage, pct, operation)

            if settings.MOCK_MODELS:
                results, summary = await mock_analyze_equipment(
                    job.selected_equipment_ids,
                    job.video_path or "",
                    settings.PREDICTION_HORIZONS,
                    progress_callback=progress_cb,
                )
            else:
                # TODO: Phase 2 — real Cosmos pipeline
                results, summary = await mock_analyze_equipment(
                    job.selected_equipment_ids,
                    job.video_path or "",
                    settings.PREDICTION_HORIZONS,
                    progress_callback=progress_cb,
                )

            job.equipment_results = results
            job.analysis_summary = summary

            # Video rendering stage
            job.update_progress("video_rendering", 90, "Rendering output video")
            await asyncio.sleep(1.0)  # TODO: Phase 4 — real video pipeline

            job.update_progress("video_rendering", 100, "Complete")
            job.transition(JobStatus.COMPLETE)
            logger.info("Job %s: analysis complete", job_id)

        except Exception as e:
            logger.exception("Job %s: analysis failed", job_id)
            job.fail(str(e))
        finally:
            self._active_tasks.pop(job_id, None)


# Singleton
orchestrator = JobOrchestrator()
