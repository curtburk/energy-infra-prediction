"""
Model Manager — singleton that owns the lifecycle of Cosmos models.

In MOCK mode, returns synthetic results for development/testing.
In production mode, loads real Cosmos-Reason1-7B and Cosmos-Predict2.5-2B.
"""

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


class ModelManager:
    """Manages Cosmos model loading, health, and inference dispatch."""

    def __init__(self):
        self.reason_loaded: bool = False
        self.predict_loaded: bool = False
        self._reason_model = None
        self._reason_processor = None
        self._predict_pipeline = None

    # -- Lifecycle ---------------------------------------------------------

    async def load_all(self) -> None:
        """Load both Cosmos models into GPU memory."""
        await self.load_reason()
        await self.load_predict()

    async def load_reason(self) -> None:
        """Load Cosmos-Reason1-7B."""
        logger.info("Loading Cosmos-Reason1-7B...")
        # TODO: Phase 2 — real model loading
        # from transformers import AutoModelForCausalLM, AutoProcessor
        # self._reason_processor = AutoProcessor.from_pretrained(...)
        # self._reason_model = AutoModelForCausalLM.from_pretrained(...)
        self.reason_loaded = True
        logger.info("Cosmos-Reason1-7B loaded (stub).")

    async def load_predict(self) -> None:
        """Load Cosmos-Predict2.5-2B."""
        logger.info("Loading Cosmos-Predict2.5-2B...")
        # TODO: Phase 2 — real model loading
        # from cosmos_predict2.pipelines.video2world import Video2WorldPipeline
        # self._predict_pipeline = Video2WorldPipeline.from_config(...)
        self.predict_loaded = True
        logger.info("Cosmos-Predict2.5-2B loaded (stub).")

    async def unload_all(self) -> None:
        """Release GPU memory."""
        self._reason_model = None
        self._reason_processor = None
        self._predict_pipeline = None
        self.reason_loaded = False
        self.predict_loaded = False
        logger.info("All models unloaded.")

    # -- Health ------------------------------------------------------------

    def get_vram_available_gb(self) -> int:
        """Return estimated available VRAM in GB."""
        # TODO: Phase 2 — real GPU memory query via pynvml or nvidia-smi
        if self.reason_loaded and self.predict_loaded:
            return 56  # ~128 - 72
        elif self.reason_loaded:
            return 104  # ~128 - 24
        elif self.predict_loaded:
            return 80  # ~128 - 48
        return 128


# Singleton
model_manager = ModelManager()
