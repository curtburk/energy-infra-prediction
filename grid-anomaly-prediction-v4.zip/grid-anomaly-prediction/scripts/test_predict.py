#!/usr/bin/env python3
"""
Test Cosmos-Predict2.5-2B integration.

Prerequisites:
  1. cosmos-predict2.5 repo cloned and installed
  2. Model checkpoints downloaded

Usage:
    python scripts/test_predict.py
    python scripts/test_predict.py --repo ~/cosmos-predict2.5
"""

import argparse
import asyncio
import logging
import sys
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


async def main():
    parser = argparse.ArgumentParser(description="Test Cosmos Predict integration")
    parser.add_argument("--repo", default=None, help="Path to cosmos-predict2.5 repo")
    args = parser.parse_args()

    logger.info("=" * 50)
    logger.info(" Cosmos Predict Integration Test")
    logger.info("=" * 50)

    from backend.services.cosmos_predict import CosmosPredictService

    service = CosmosPredictService(repo_dir=args.repo) if args.repo else CosmosPredictService()

    # Test 1: Availability check
    logger.info("Repo dir: %s", service.repo_dir)
    available = service.check_available()

    if not available:
        logger.error("✗ Cosmos Predict is not available.")
        logger.error("  Clone the repo: git clone https://github.com/nvidia-cosmos/cosmos-predict2.5.git ~/cosmos-predict2.5")
        logger.error("  Or set: export COSMOS_PREDICT_DIR=/path/to/repo")
        logger.info("")
        logger.info("NOTE: Cosmos Predict is OPTIONAL for the core demo.")
        logger.info("  Equipment detection and anomaly classification (Cosmos Reason)")
        logger.info("  work independently. Future state video generation is a bonus feature.")
        sys.exit(1)

    logger.info("✓ Cosmos Predict is available.")

    # Test 2: Try generating a prediction (requires GPU + checkpoints)
    demo_dir = PROJECT_ROOT / "data" / "demo_videos"
    demos = list(demo_dir.glob("*.mp4")) if demo_dir.exists() else []

    if demos:
        logger.info("")
        logger.info("Testing Video2World generation (this will take 1-3 minutes)...")

        output_dir = str(PROJECT_ROOT / "data" / "test_predict_output")
        result = await service.predict_future_state(
            input_video=str(demos[0]),
            prompt=(
                "A power transformer at an electrical substation showing "
                "progressive oil leak degradation after 30 days. "
                "Dark staining visible at the base seal area."
            ),
            output_dir=output_dir,
            name="test_prediction",
            timeout=300,
        )

        if result:
            logger.info("✓ Generated prediction video: %s", result)
        else:
            logger.warning("✗ Prediction generation failed or timed out.")
            logger.info("  Check GPU memory and model checkpoints.")
    else:
        logger.info("No demo videos found — skipping generation test.")
        logger.info("  Run Phase 1 first: ./scripts/prepare_demo_data.sh")

    logger.info("")
    logger.info("=" * 50)
    logger.info(" Test complete")
    logger.info("=" * 50)


if __name__ == "__main__":
    asyncio.run(main())
