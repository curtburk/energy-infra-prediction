"""
Cosmos Predict inference service.

Wraps Cosmos-Predict2.5-2B Video2World as a subprocess for generating
future state video predictions.

The Cosmos Predict package runs as its own process with CUDA memory
management, so we call it via subprocess rather than importing directly.

Requires:
  - cosmos-predict2.5 repo cloned and installed
  - Model checkpoints downloaded
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import subprocess
import tempfile
from pathlib import Path
from typing import List, Optional

from backend.config import settings

logger = logging.getLogger(__name__)

# Default path to cosmos-predict2.5 repo — set via env var
COSMOS_PREDICT_DIR = os.getenv(
    "COSMOS_PREDICT_DIR",
    os.path.expanduser("~/cosmos-predict2.5"),
)


class CosmosPredictService:
    """Calls Cosmos-Predict2.5-2B Video2World for future state generation."""

    def __init__(self, repo_dir: str = None):
        self.repo_dir = repo_dir or COSMOS_PREDICT_DIR
        self._available: Optional[bool] = None

    def check_available(self) -> bool:
        """Check if cosmos-predict2.5 is installed and accessible."""
        if self._available is not None:
            return self._available

        repo_path = Path(self.repo_dir)
        if not repo_path.exists():
            logger.warning(
                "Cosmos Predict repo not found at %s. "
                "Set COSMOS_PREDICT_DIR env var or clone to ~/cosmos-predict2.5",
                self.repo_dir,
            )
            self._available = False
            return False

        inference_script = repo_path / "examples" / "inference.py"
        if not inference_script.exists():
            # Try cosmos-predict2 (older repo) layout
            inference_script = repo_path / "examples" / "video2world.py"

        if not inference_script.exists():
            logger.warning("Inference script not found in %s", self.repo_dir)
            self._available = False
            return False

        self._available = True
        return True

    def _build_input_json(
        self,
        input_video: str,
        prompt: str,
        name: str = "prediction",
    ) -> str:
        """Create a JSON input file for the inference script."""
        input_config = {
            "inference_type": "video2world",
            "name": name,
            "prompt": prompt,
            "input_path": input_video,
        }

        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False, prefix="cosmos_predict_"
        )
        json.dump(input_config, tmp, indent=2)
        tmp.close()
        return tmp.name

    async def predict_future_state(
        self,
        input_video: str,
        prompt: str,
        output_dir: str,
        name: str = "prediction",
        timeout: int = 600,
    ) -> Optional[str]:
        """
        Generate a future state video using Video2World.

        Args:
            input_video: Path to input video/image
            prompt: Text describing the expected future state
            output_dir: Directory to save output video
            name: Identifier for this prediction
            timeout: Max seconds to wait for inference

        Returns:
            Path to generated video file, or None on failure.
        """
        if not self.check_available():
            logger.error("Cosmos Predict is not available")
            return None

        os.makedirs(output_dir, exist_ok=True)

        # Build input JSON
        input_json = self._build_input_json(input_video, prompt, name)
        logger.info("Cosmos Predict input config: %s", input_json)

        # Determine inference script path
        repo_path = Path(self.repo_dir)
        # Try predict2.5 layout first, fall back to predict2
        if (repo_path / "examples" / "inference.py").exists():
            script = "examples/inference.py"
            cmd = [
                "python", script,
                "-i", input_json,
                "-o", output_dir,
                "--inference-type", "video2world",
            ]
        else:
            script = "examples/video2world.py"
            cmd = [
                "python", "-m", script.replace("/", ".").replace(".py", ""),
                "--model_size", "2B",
                "--input_path", input_video,
                "--prompt", prompt,
                "--save_path", os.path.join(output_dir, f"{name}.mp4"),
            ]

        # Add memory optimization flags
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = "0"
        env["PYTHONPATH"] = self.repo_dir

        logger.info("Running Cosmos Predict: %s", " ".join(cmd))

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=self.repo_dir,
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )

            if proc.returncode != 0:
                logger.error(
                    "Cosmos Predict failed (exit %d):\n%s",
                    proc.returncode,
                    stderr.decode()[-2000:],
                )
                return None

            logger.info("Cosmos Predict output:\n%s", stdout.decode()[-1000:])

            # Find output video
            output_path = Path(output_dir)
            videos = list(output_path.rglob("*.mp4"))
            if videos:
                result = str(videos[0])
                logger.info("Generated future state video: %s", result)
                return result

            logger.warning("No output video found in %s", output_dir)
            return None

        except asyncio.TimeoutError:
            logger.error("Cosmos Predict timed out after %ds", timeout)
            proc.kill()
            return None
        except Exception as e:
            logger.error("Cosmos Predict error: %s", e)
            return None
        finally:
            # Clean up temp input JSON
            try:
                os.unlink(input_json)
            except OSError:
                pass

    async def generate_degradation_sequence(
        self,
        input_video: str,
        equipment_type: str,
        anomaly_type: str,
        horizons: List[int],
        output_dir: str,
    ) -> List[Optional[str]]:
        """
        Generate future state videos for multiple time horizons.

        Returns list of output video paths (one per horizon).
        """
        results = []
        for days in horizons:
            prompt = self._build_degradation_prompt(
                equipment_type, anomaly_type, days
            )
            name = f"{equipment_type}_{anomaly_type}_{days}d"
            horizon_dir = os.path.join(output_dir, name)

            logger.info(
                "Generating +%d day prediction for %s (%s)",
                days, equipment_type, anomaly_type,
            )

            result = await self.predict_future_state(
                input_video=input_video,
                prompt=prompt,
                output_dir=horizon_dir,
                name=name,
            )
            results.append(result)

        return results

    def _build_degradation_prompt(
        self,
        equipment_type: str,
        anomaly_type: str,
        horizon_days: int,
    ) -> str:
        """Build a detailed prompt for future state generation."""
        prompts = {
            "oil_leak": {
                30: (
                    f"A high-definition surveillance video of a {equipment_type} at an electrical "
                    f"substation showing progressive oil leak degradation after 30 days. "
                    f"The dark oil stain at the base has expanded by 15-20%, with visible drip "
                    f"patterns extending downward. The wet appearance has spread to adjacent surfaces. "
                    f"The equipment remains stationary. Natural daylight. Industrial substation background."
                ),
                60: (
                    f"A high-definition surveillance video of a {equipment_type} at an electrical "
                    f"substation showing significant oil leak after 60 days. "
                    f"The oil stain covers a large area at the base, with pooling visible on the ground. "
                    f"Surface discoloration is prominent. Oil level markings suggest depletion. "
                    f"The equipment remains stationary. Natural daylight. Industrial substation background."
                ),
                90: (
                    f"A high-definition surveillance video of a {equipment_type} at an electrical "
                    f"substation showing critical oil leak after 90 days. "
                    f"Extensive oil staining and pooling. Visible thermal discoloration from overheating "
                    f"due to oil loss. Secondary damage patterns emerging on adjacent components. "
                    f"The equipment remains stationary. Natural daylight. Industrial substation background."
                ),
            },
            "contamination": {
                30: (
                    f"A high-definition surveillance video of a {equipment_type} bushing at an "
                    f"electrical substation showing surface contamination buildup after 30 days. "
                    f"Light gray-brown deposits accumulating on the ceramic surface. "
                    f"Early-stage contamination visible on the lower skirts. "
                    f"The equipment remains stationary. Natural daylight."
                ),
                60: (
                    f"A high-definition surveillance video of a {equipment_type} bushing at an "
                    f"electrical substation showing moderate contamination after 60 days. "
                    f"Dense deposits covering multiple skirts. Visible tracking paths. "
                    f"The equipment remains stationary. Natural daylight."
                ),
                90: (
                    f"A high-definition surveillance video of a {equipment_type} bushing at an "
                    f"electrical substation showing heavy contamination after 90 days. "
                    f"Thick deposits with flashover risk. Tracking marks visible. "
                    f"The equipment remains stationary. Natural daylight."
                ),
            },
        }

        type_prompts = prompts.get(anomaly_type, {})
        if horizon_days in type_prompts:
            return type_prompts[horizon_days]

        # Generic fallback
        return (
            f"A high-definition surveillance video of a {equipment_type} at an electrical "
            f"substation showing progressive {anomaly_type.replace('_', ' ')} degradation "
            f"after {horizon_days} days. The damage has visibly worsened compared to the initial state. "
            f"The equipment remains stationary. Natural daylight. Industrial substation background."
        )
